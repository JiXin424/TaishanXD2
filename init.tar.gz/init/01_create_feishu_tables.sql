-- ============================================================
-- omni_feishu 数据库初始化
-- 飞书平台专用数据库，包含所有飞书相关表
-- ============================================================

-- feishu_users: 飞书用户档案
CREATE TABLE IF NOT EXISTS feishu_users (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) UNIQUE NOT NULL,
    open_id VARCHAR(64) UNIQUE NOT NULL,
    union_id VARCHAR(64),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    mobile VARCHAR(32),
    gender INTEGER,
    avatar_key VARCHAR(255),
    department_ids TEXT[],
    leader_user_id VARCHAR(64),
    orders TEXT,
    department_path TEXT,
    dotted_line_leader_user_ids TEXT[],
    job_family_id VARCHAR(64),
    job_level_id VARCHAR(64),
    user_geo VARCHAR(255),
    is_frozen BOOLEAN DEFAULT FALSE,
    job_title VARCHAR(100),
    join_time BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_feishu_users_name ON feishu_users(name);
CREATE INDEX IF NOT EXISTS idx_feishu_users_email ON feishu_users(email);

-- feishu_messages: 飞书消息
CREATE TABLE IF NOT EXISTS feishu_messages (
    id SERIAL PRIMARY KEY,
    message_id VARCHAR(64) UNIQUE NOT NULL,
    root_id VARCHAR(64),
    parent_id VARCHAR(64),
    thread_id VARCHAR(64),
    chat_id VARCHAR(64),
    msg_type VARCHAR(32) NOT NULL,
    content TEXT,
    sender_id VARCHAR(64),
    sender_id_type VARCHAR(32),
    sender_type VARCHAR(32),
    sender_tenant_key VARCHAR(64),
    receive_id VARCHAR(64),
    receive_id_type VARCHAR(32),
    direction VARCHAR(10),
    create_time BIGINT,
    update_time BIGINT,
    deleted BOOLEAN DEFAULT FALSE,
    updated BOOLEAN DEFAULT FALSE,
    mentions JSONB,
    upper_message_id VARCHAR(64),
    raw_data JSONB,
    synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON feishu_messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_messages_thread_id ON feishu_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON feishu_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_create_time ON feishu_messages(create_time);
CREATE INDEX IF NOT EXISTS idx_messages_direction ON feishu_messages(direction);

-- feishu_chats: 飞书群聊
CREATE TABLE IF NOT EXISTS feishu_chats (
    id SERIAL PRIMARY KEY,
    chat_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(255),
    description TEXT,
    avatar VARCHAR(512),
    i18n_names JSONB,
    chat_type VARCHAR(32),
    owner_user_id VARCHAR(64),
    only_owner_add BOOLEAN DEFAULT FALSE,
    share_allowed BOOLEAN DEFAULT FALSE,
    only_owner_at_all BOOLEAN DEFAULT FALSE,
    only_owner_edit BOOLEAN DEFAULT FALSE,
    labels TEXT[],
    synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- feishu_events: 飞书事件
CREATE TABLE IF NOT EXISTS feishu_events (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(64) UNIQUE NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    tenant_key VARCHAR(64),
    app_id VARCHAR(64),
    create_time BIGINT,
    raw_data JSONB NOT NULL,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_events_event_type ON feishu_events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_create_time ON feishu_events(create_time);
CREATE INDEX IF NOT EXISTS idx_events_received_at ON feishu_events(received_at);

-- rag_query_log: RAG查询日志
CREATE TABLE IF NOT EXISTS rag_query_log (
    id SERIAL PRIMARY KEY,
    question TEXT NOT NULL,
    retrieved_chunk_ids TEXT[],
    response TEXT,
    latency_ms INTEGER,
    message_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_rag_query_log_created ON rag_query_log(created_at);
CREATE INDEX IF NOT EXISTS idx_rag_query_log_message_id ON rag_query_log(message_id);

-- document_chunks: 文档分片存储
CREATE TABLE IF NOT EXISTS document_chunks (
    id SERIAL PRIMARY KEY,
    chunk_text TEXT NOT NULL,
    source_file VARCHAR(500),
    chunk_index INTEGER,
    embedding_id VARCHAR(64),
    collection_name VARCHAR(100),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_document_chunks_collection ON document_chunks(collection_name);
CREATE INDEX IF NOT EXISTS idx_document_chunks_embedding_id ON document_chunks(embedding_id);
CREATE INDEX IF NOT EXISTS idx_document_chunks_source ON document_chunks(source_file);

-- node_execution_records: 节点执行记录
CREATE TABLE IF NOT EXISTS node_execution_records (
    id SERIAL PRIMARY KEY,
    workflow_name VARCHAR(200) NOT NULL,
    node_id VARCHAR(100) NOT NULL,
    node_title VARCHAR(200),
    node_type VARCHAR(50) NOT NULL,
    execution_id VARCHAR(64),
    state VARCHAR(20) NOT NULL,
    inputs JSONB,
    outputs JSONB,
    stdout TEXT,
    error TEXT,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_node_records_workflow ON node_execution_records(workflow_name);
CREATE INDEX IF NOT EXISTS idx_node_records_node_id ON node_execution_records(node_id);
CREATE INDEX IF NOT EXISTS idx_node_records_execution_id ON node_execution_records(execution_id);
CREATE INDEX IF NOT EXISTS idx_node_records_created_at ON node_execution_records(created_at DESC);

-- sales_users: 销售用户档案（教练系统）
CREATE TABLE IF NOT EXISTS sales_users (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(64) NOT NULL,
    level INTEGER NOT NULL DEFAULT 0,
    total_milestones INTEGER NOT NULL DEFAULT 0,
    stage VARCHAR(8) NOT NULL DEFAULT 'P0',
    feishu_user_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- sales_competency_scores: 能力维度评分
CREATE TABLE IF NOT EXISTS sales_competency_scores (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    dimension VARCHAR(16) NOT NULL,
    score INTEGER NOT NULL DEFAULT 50,
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, dimension)
);

-- sales_competency_observations: 能力观察记录
CREATE TABLE IF NOT EXISTS sales_competency_observations (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    dimension VARCHAR(16) NOT NULL,
    delta INTEGER NOT NULL,
    previous_score INTEGER NOT NULL,
    new_score INTEGER NOT NULL,
    evidence TEXT,
    source VARCHAR(32) DEFAULT 'conversation',
    obs_date DATE NOT NULL,
    observed_at TIMESTAMP DEFAULT NOW()
);

-- sales_milestone_progress: 里程碑进度
CREATE TABLE IF NOT EXISTS sales_milestone_progress (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    milestone_type VARCHAR(16) NOT NULL,
    dimension VARCHAR(16),
    score_threshold INTEGER NOT NULL,
    unlocked_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, milestone_type, dimension, score_threshold)
);

-- sales_rewards: 奖励发放
CREATE TABLE IF NOT EXISTS sales_rewards (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    milestone_type VARCHAR(16) NOT NULL,
    dimension VARCHAR(16),
    score_threshold INTEGER NOT NULL,
    reward_type VARCHAR(32) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'sent',
    content TEXT,
    sent_at TIMESTAMP DEFAULT NOW()
);
