--
-- PostgreSQL database dump
--

\restrict y8c2YLpU9SO8YMzqzDrMyB8qi21qbJFBKDVsOMMtTFfDfAdQlEwYfOKnLE5rLAo

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_chunks (
    id integer NOT NULL,
    chunk_text text NOT NULL,
    source_file character varying(500),
    chunk_index integer,
    embedding_id character varying(64),
    collection_name character varying(100),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: document_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_chunks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_chunks_id_seq OWNED BY public.document_chunks.id;


--
-- Name: document_chunks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks ALTER COLUMN id SET DEFAULT nextval('public.document_chunks_id_seq'::regclass);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- Name: idx_document_chunks_collection; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_chunks_collection ON public.document_chunks USING btree (collection_name);


--
-- Name: idx_document_chunks_embedding_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_chunks_embedding_id ON public.document_chunks USING btree (embedding_id);


--
-- Name: idx_document_chunks_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_chunks_source ON public.document_chunks USING btree (source_file);


--
-- PostgreSQL database dump complete
--

\unrestrict y8c2YLpU9SO8YMzqzDrMyB8qi21qbJFBKDVsOMMtTFfDfAdQlEwYfOKnLE5rLAo

