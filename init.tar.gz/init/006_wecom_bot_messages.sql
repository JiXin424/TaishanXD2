-- 企微智能机器人消息表
-- 用于存储 WebSocket 长连接模式下的机器人收发消息记录

CREATE TABLE IF NOT EXISTS wecom_bot_messages (
    id SERIAL PRIMARY KEY,
    message_id VARCHAR(128) UNIQUE NOT NULL,
    from_userid VARCHAR(128),
    chat_id VARCHAR(128),
    msg_type VARCHAR(32),
    content TEXT,
    direction VARCHAR(16) DEFAULT 'received',
    stream_id VARCHAR(64),
    req_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wecom_bot_messages_chat_id ON wecom_bot_messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_wecom_bot_messages_from_userid ON wecom_bot_messages(from_userid);
CREATE INDEX IF NOT EXISTS idx_wecom_bot_messages_created_at ON wecom_bot_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_wecom_bot_messages_direction ON wecom_bot_messages(direction);
