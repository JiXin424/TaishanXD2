--
-- PostgreSQL database dump
--

\restrict rBZXJszMFcC3zFgXuY17LyR3emhgnmZqhbaZkFJNPRcjfz0Oq9hpV7pl9clNd3e

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sales_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_rewards (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    milestone_type character varying(16) NOT NULL,
    dimension character varying(16),
    score_threshold integer NOT NULL,
    reward_type character varying(32) NOT NULL,
    status character varying(16) DEFAULT 'sent'::character varying NOT NULL,
    content text,
    sent_at timestamp without time zone DEFAULT now()
);


--
-- Name: sales_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_rewards_id_seq OWNED BY public.sales_rewards.id;


--
-- Name: sales_rewards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_rewards ALTER COLUMN id SET DEFAULT nextval('public.sales_rewards_id_seq'::regclass);


--
-- Name: sales_rewards sales_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_rewards
    ADD CONSTRAINT sales_rewards_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict rBZXJszMFcC3zFgXuY17LyR3emhgnmZqhbaZkFJNPRcjfz0Oq9hpV7pl9clNd3e

