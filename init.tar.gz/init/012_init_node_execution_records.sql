--
-- PostgreSQL database dump
--

\restrict r36ktKj2a0fx5jstqAMiTtu0tCu3jkoygzOBRXDyLHco4BwGCtkRGGrPabgexqu

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: node_execution_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_execution_records (
    id integer NOT NULL,
    workflow_name character varying(200) NOT NULL,
    node_id character varying(100) NOT NULL,
    node_title character varying(200),
    node_type character varying(50) NOT NULL,
    execution_id character varying(64),
    state character varying(20) NOT NULL,
    inputs jsonb,
    outputs jsonb,
    stdout text,
    error text,
    raw_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: node_execution_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.node_execution_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: node_execution_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.node_execution_records_id_seq OWNED BY public.node_execution_records.id;


--
-- Name: node_execution_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_execution_records ALTER COLUMN id SET DEFAULT nextval('public.node_execution_records_id_seq'::regclass);


--
-- Name: node_execution_records node_execution_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_execution_records
    ADD CONSTRAINT node_execution_records_pkey PRIMARY KEY (id);


--
-- Name: idx_node_records_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_records_created_at ON public.node_execution_records USING btree (created_at DESC);


--
-- Name: idx_node_records_execution_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_records_execution_id ON public.node_execution_records USING btree (execution_id);


--
-- Name: idx_node_records_node_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_records_node_id ON public.node_execution_records USING btree (node_id);


--
-- Name: idx_node_records_workflow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_node_records_workflow ON public.node_execution_records USING btree (workflow_name);


--
-- PostgreSQL database dump complete
--

\unrestrict r36ktKj2a0fx5jstqAMiTtu0tCu3jkoygzOBRXDyLHco4BwGCtkRGGrPabgexqu

