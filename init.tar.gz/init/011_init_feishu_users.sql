--
-- PostgreSQL database dump
--

\restrict pDMRnatBbU5iD1kKpZeYY4HAlE0FfbBvmKLf7pRhkl8QeljsAuBTbeunIXGKVkM

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: feishu_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feishu_users (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    open_id character varying(64) NOT NULL,
    union_id character varying(64),
    name character varying(100) NOT NULL,
    email character varying(255),
    mobile character varying(32),
    gender integer,
    avatar_key character varying(255),
    department_ids text[],
    leader_user_id character varying(64),
    orders text,
    department_path text,
    dotted_line_leader_user_ids text[],
    job_family_id character varying(64),
    job_level_id character varying(64),
    user_geo character varying(255),
    is_frozen boolean DEFAULT false,
    job_title character varying(100),
    join_time bigint,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feishu_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feishu_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feishu_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feishu_users_id_seq OWNED BY public.feishu_users.id;


--
-- Name: feishu_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_users ALTER COLUMN id SET DEFAULT nextval('public.feishu_users_id_seq'::regclass);


--
-- Name: feishu_users feishu_users_open_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_users
    ADD CONSTRAINT feishu_users_open_id_key UNIQUE (open_id);


--
-- Name: feishu_users feishu_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_users
    ADD CONSTRAINT feishu_users_pkey PRIMARY KEY (id);


--
-- Name: feishu_users feishu_users_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_users
    ADD CONSTRAINT feishu_users_user_id_key UNIQUE (user_id);


--
-- Name: idx_feishu_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feishu_users_email ON public.feishu_users USING btree (email);


--
-- Name: idx_feishu_users_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feishu_users_name ON public.feishu_users USING btree (name);


--
-- PostgreSQL database dump complete
--

\unrestrict pDMRnatBbU5iD1kKpZeYY4HAlE0FfbBvmKLf7pRhkl8QeljsAuBTbeunIXGKVkM

