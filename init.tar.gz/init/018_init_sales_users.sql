--
-- PostgreSQL database dump
--

\restrict R0nLG0nBvw43fAXLmH2E2VR8sZlV94gUSJpJnHJtpbd8gerOKjMhBoWt5cTRvpl

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sales_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_users (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    name character varying(64) NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    total_milestones integer DEFAULT 0 NOT NULL,
    stage character varying(8) DEFAULT 'P0'::character varying NOT NULL,
    feishu_user_id character varying(64),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: sales_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_users_id_seq OWNED BY public.sales_users.id;


--
-- Name: sales_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_users ALTER COLUMN id SET DEFAULT nextval('public.sales_users_id_seq'::regclass);


--
-- Name: sales_users sales_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_users
    ADD CONSTRAINT sales_users_pkey PRIMARY KEY (id);


--
-- Name: sales_users sales_users_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_users
    ADD CONSTRAINT sales_users_user_id_key UNIQUE (user_id);


--
-- PostgreSQL database dump complete
--

\unrestrict R0nLG0nBvw43fAXLmH2E2VR8sZlV94gUSJpJnHJtpbd8gerOKjMhBoWt5cTRvpl

