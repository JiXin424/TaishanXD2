--
-- PostgreSQL database dump
--

\restrict Ib7HBAmyNWwTFmCdzUGqUgc8Q9D3q8lCabI6CW1BQlKCTwCkdhvsd5xVr6ESIGy

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sales_milestone_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_milestone_progress (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    milestone_type character varying(16) NOT NULL,
    dimension character varying(16),
    score_threshold integer NOT NULL,
    unlocked_at timestamp without time zone DEFAULT now()
);


--
-- Name: sales_milestone_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_milestone_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_milestone_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_milestone_progress_id_seq OWNED BY public.sales_milestone_progress.id;


--
-- Name: sales_milestone_progress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_milestone_progress ALTER COLUMN id SET DEFAULT nextval('public.sales_milestone_progress_id_seq'::regclass);


--
-- Name: sales_milestone_progress sales_milestone_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_milestone_progress
    ADD CONSTRAINT sales_milestone_progress_pkey PRIMARY KEY (id);


--
-- Name: sales_milestone_progress sales_milestone_progress_user_id_milestone_type_dimension_s_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_milestone_progress
    ADD CONSTRAINT sales_milestone_progress_user_id_milestone_type_dimension_s_key UNIQUE (user_id, milestone_type, dimension, score_threshold);


--
-- PostgreSQL database dump complete
--

\unrestrict Ib7HBAmyNWwTFmCdzUGqUgc8Q9D3q8lCabI6CW1BQlKCTwCkdhvsd5xVr6ESIGy

