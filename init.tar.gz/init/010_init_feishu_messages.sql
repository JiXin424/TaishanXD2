--
-- PostgreSQL database dump
--

\restrict cNdjSZPGZQPTaSvw1eYVRUd90B2lON3tVHOQOdFGlIQjYD6hogl7ejB7FROeEfh

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: feishu_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feishu_messages (
    id integer NOT NULL,
    message_id character varying(64) NOT NULL,
    root_id character varying(64),
    parent_id character varying(64),
    thread_id character varying(64),
    chat_id character varying(64),
    msg_type character varying(32) NOT NULL,
    content text,
    sender_id character varying(64),
    sender_id_type character varying(32),
    sender_type character varying(32),
    sender_tenant_key character varying(64),
    receive_id character varying(64),
    receive_id_type character varying(32),
    direction character varying(10),
    create_time bigint,
    update_time bigint,
    deleted boolean DEFAULT false,
    updated boolean DEFAULT false,
    mentions jsonb,
    upper_message_id character varying(64),
    raw_data jsonb,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feishu_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feishu_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feishu_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feishu_messages_id_seq OWNED BY public.feishu_messages.id;


--
-- Name: feishu_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_messages ALTER COLUMN id SET DEFAULT nextval('public.feishu_messages_id_seq'::regclass);


--
-- Name: feishu_messages feishu_messages_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_messages
    ADD CONSTRAINT feishu_messages_message_id_key UNIQUE (message_id);


--
-- Name: feishu_messages feishu_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_messages
    ADD CONSTRAINT feishu_messages_pkey PRIMARY KEY (id);


--
-- Name: idx_messages_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_chat_id ON public.feishu_messages USING btree (chat_id);


--
-- Name: idx_messages_create_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_create_time ON public.feishu_messages USING btree (create_time);


--
-- Name: idx_messages_direction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_direction ON public.feishu_messages USING btree (direction);


--
-- Name: idx_messages_sender_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_sender_id ON public.feishu_messages USING btree (sender_id);


--
-- Name: idx_messages_thread_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_thread_id ON public.feishu_messages USING btree (thread_id);


--
-- PostgreSQL database dump complete
--

\unrestrict cNdjSZPGZQPTaSvw1eYVRUd90B2lON3tVHOQOdFGlIQjYD6hogl7ejB7FROeEfh

