--
-- PostgreSQL database dump
--

\restrict wF41jXJ8u8X9M1wZoZxaZG7TcVptcFirkJmbkSar51OiwEFykeNMJ5sEqo1HNkg

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: feishu_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feishu_events (
    id integer NOT NULL,
    event_id character varying(64) NOT NULL,
    event_type character varying(64) NOT NULL,
    tenant_key character varying(64),
    app_id character varying(64),
    create_time bigint,
    raw_data jsonb NOT NULL,
    received_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feishu_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feishu_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feishu_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feishu_events_id_seq OWNED BY public.feishu_events.id;


--
-- Name: feishu_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_events ALTER COLUMN id SET DEFAULT nextval('public.feishu_events_id_seq'::regclass);


--
-- Name: feishu_events feishu_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_events
    ADD CONSTRAINT feishu_events_event_id_key UNIQUE (event_id);


--
-- Name: feishu_events feishu_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_events
    ADD CONSTRAINT feishu_events_pkey PRIMARY KEY (id);


--
-- Name: idx_events_create_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_create_time ON public.feishu_events USING btree (create_time);


--
-- Name: idx_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_event_type ON public.feishu_events USING btree (event_type);


--
-- Name: idx_events_received_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_events_received_at ON public.feishu_events USING btree (received_at);


--
-- PostgreSQL database dump complete
--

\unrestrict wF41jXJ8u8X9M1wZoZxaZG7TcVptcFirkJmbkSar51OiwEFykeNMJ5sEqo1HNkg

