--
-- PostgreSQL database dump
--

\restrict 82MG9FaKessrdYlDVAeI2c1vtAYEYkPoOOASexLcm6vhsoJlkXtzETBpJCXbAF1

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sales_competency_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_competency_observations (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    dimension character varying(16) NOT NULL,
    delta integer NOT NULL,
    previous_score integer NOT NULL,
    new_score integer NOT NULL,
    evidence text,
    source character varying(32) DEFAULT 'conversation'::character varying,
    obs_date date NOT NULL,
    observed_at timestamp without time zone DEFAULT now()
);


--
-- Name: sales_competency_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_competency_observations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_competency_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_competency_observations_id_seq OWNED BY public.sales_competency_observations.id;


--
-- Name: sales_competency_observations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_competency_observations ALTER COLUMN id SET DEFAULT nextval('public.sales_competency_observations_id_seq'::regclass);


--
-- Name: sales_competency_observations sales_competency_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_competency_observations
    ADD CONSTRAINT sales_competency_observations_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 82MG9FaKessrdYlDVAeI2c1vtAYEYkPoOOASexLcm6vhsoJlkXtzETBpJCXbAF1

