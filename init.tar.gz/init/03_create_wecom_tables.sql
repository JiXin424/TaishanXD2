-- ============================================================
-- omni_wecom 数据库初始化
-- 企业微信平台专用数据库，表名使用 wecom_ 前缀
-- ============================================================

-- wecom_users: 企微用户档案
CREATE TABLE IF NOT EXISTS wecom_users (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) UNIQUE NOT NULL,
    open_id VARCHAR(64) UNIQUE NOT NULL,
    union_id VARCHAR(64),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    mobile VARCHAR(32),
    gender INTEGER,
    avatar_key VARCHAR(255),
    department_ids TEXT[],
    leader_user_id VARCHAR(64),
    orders TEXT,
    department_path TEXT,
    dotted_line_leader_user_ids TEXT[],
    job_family_id VARCHAR(64),
    job_level_id VARCHAR(64),
    user_geo VARCHAR(255),
    is_frozen BOOLEAN DEFAULT FALSE,
    job_title VARCHAR(100),
    join_time BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wecom_users_name ON wecom_users(name);
CREATE INDEX IF NOT EXISTS idx_wecom_users_email ON wecom_users(email);

-- wecom_messages: 企微消息
CREATE TABLE IF NOT EXISTS wecom_messages (
    id SERIAL PRIMARY KEY,
    message_id VARCHAR(64) UNIQUE NOT NULL,
    root_id VARCHAR(64),
    parent_id VARCHAR(64),
    thread_id VARCHAR(64),
    chat_id VARCHAR(64),
    msg_type VARCHAR(32) NOT NULL,
    content TEXT,
    sender_id VARCHAR(64),
    sender_id_type VARCHAR(32),
    sender_type VARCHAR(32),
    sender_tenant_key VARCHAR(64),
    receive_id VARCHAR(64),
    receive_id_type VARCHAR(32),
    direction VARCHAR(10),
    create_time BIGINT,
    update_time BIGINT,
    deleted BOOLEAN DEFAULT FALSE,
    updated BOOLEAN DEFAULT FALSE,
    mentions JSONB,
    upper_message_id VARCHAR(64),
    raw_data JSONB,
    synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wecom_messages_chat_id ON wecom_messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_wecom_messages_thread_id ON wecom_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_wecom_messages_sender_id ON wecom_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_wecom_messages_create_time ON wecom_messages(create_time);
CREATE INDEX IF NOT EXISTS idx_wecom_messages_direction ON wecom_messages(direction);

-- wecom_chats: 企微群聊
CREATE TABLE IF NOT EXISTS wecom_chats (
    id SERIAL PRIMARY KEY,
    chat_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(255),
    description TEXT,
    avatar VARCHAR(512),
    i18n_names JSONB,
    chat_type VARCHAR(32),
    owner_user_id VARCHAR(64),
    only_owner_add BOOLEAN DEFAULT FALSE,
    share_allowed BOOLEAN DEFAULT FALSE,
    only_owner_at_all BOOLEAN DEFAULT FALSE,
    only_owner_edit BOOLEAN DEFAULT FALSE,
    labels TEXT[],
    synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- wecom_events: 企微事件
CREATE TABLE IF NOT EXISTS wecom_events (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(64) UNIQUE NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    tenant_key VARCHAR(64),
    app_id VARCHAR(64),
    create_time BIGINT,
    raw_data JSONB NOT NULL,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wecom_events_event_type ON wecom_events(event_type);
CREATE INDEX IF NOT EXISTS idx_wecom_events_create_time ON wecom_events(create_time);
CREATE INDEX IF NOT EXISTS idx_wecom_events_received_at ON wecom_events(received_at);
