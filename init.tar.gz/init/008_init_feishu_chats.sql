--
-- PostgreSQL database dump
--

\restrict 8WzPT6aSfjieL5M66OaVeFagKMfbeWwhBIFwvizlWJpbGLVzffDebbjePUiOJYy

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: feishu_chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feishu_chats (
    id integer NOT NULL,
    chat_id character varying(64) NOT NULL,
    name character varying(255),
    description text,
    avatar character varying(512),
    i18n_names jsonb,
    chat_type character varying(32),
    owner_user_id character varying(64),
    only_owner_add boolean DEFAULT false,
    share_allowed boolean DEFAULT false,
    only_owner_at_all boolean DEFAULT false,
    only_owner_edit boolean DEFAULT false,
    labels text[],
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: feishu_chats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feishu_chats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feishu_chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feishu_chats_id_seq OWNED BY public.feishu_chats.id;


--
-- Name: feishu_chats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_chats ALTER COLUMN id SET DEFAULT nextval('public.feishu_chats_id_seq'::regclass);


--
-- Name: feishu_chats feishu_chats_chat_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_chats
    ADD CONSTRAINT feishu_chats_chat_id_key UNIQUE (chat_id);


--
-- Name: feishu_chats feishu_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feishu_chats
    ADD CONSTRAINT feishu_chats_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 8WzPT6aSfjieL5M66OaVeFagKMfbeWwhBIFwvizlWJpbGLVzffDebbjePUiOJYy

