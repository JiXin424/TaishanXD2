--
-- PostgreSQL database dump
--

\restrict NsGPEyCDUiOlYdVMYpAYW3NrgQ25k1FhTFRw1wqy9m2XqgQRMTL8ArcMbiP0vWo

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: sales_competency_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_competency_scores (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    dimension character varying(16) NOT NULL,
    score integer DEFAULT 50 NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: sales_competency_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_competency_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_competency_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_competency_scores_id_seq OWNED BY public.sales_competency_scores.id;


--
-- Name: sales_competency_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_competency_scores ALTER COLUMN id SET DEFAULT nextval('public.sales_competency_scores_id_seq'::regclass);


--
-- Name: sales_competency_scores sales_competency_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_competency_scores
    ADD CONSTRAINT sales_competency_scores_pkey PRIMARY KEY (id);


--
-- Name: sales_competency_scores sales_competency_scores_user_id_dimension_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_competency_scores
    ADD CONSTRAINT sales_competency_scores_user_id_dimension_key UNIQUE (user_id, dimension);


--
-- PostgreSQL database dump complete
--

\unrestrict NsGPEyCDUiOlYdVMYpAYW3NrgQ25k1FhTFRw1wqy9m2XqgQRMTL8ArcMbiP0vWo

