--
-- PostgreSQL database dump
--

\restrict dYlt8S8iibUhmoccKmmBYZX6Tbls4XHctlXFYgNUHUGhdIkcgXKuIud6ZMisZxe

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_table_access_method = heap;

--
-- Name: rag_query_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rag_query_log (
    id integer NOT NULL,
    question text NOT NULL,
    retrieved_chunk_ids text[],
    response text,
    latency_ms integer,
    message_id character varying(64),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: rag_query_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rag_query_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rag_query_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rag_query_log_id_seq OWNED BY public.rag_query_log.id;


--
-- Name: rag_query_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_query_log ALTER COLUMN id SET DEFAULT nextval('public.rag_query_log_id_seq'::regclass);


--
-- Name: rag_query_log rag_query_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rag_query_log
    ADD CONSTRAINT rag_query_log_pkey PRIMARY KEY (id);


--
-- Name: idx_rag_query_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rag_query_log_created ON public.rag_query_log USING btree (created_at);


--
-- Name: idx_rag_query_log_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rag_query_log_message_id ON public.rag_query_log USING btree (message_id);


--
-- PostgreSQL database dump complete
--

\unrestrict dYlt8S8iibUhmoccKmmBYZX6Tbls4XHctlXFYgNUHUGhdIkcgXKuIud6ZMisZxe

